
  # MOSA Intelligence

  This is a code bundle for MOSA Intelligence. The original project is available at https://www.figma.com/design/uJI3zhFHgY8vTyrWCwADc9/MOSA-Intelligence.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  